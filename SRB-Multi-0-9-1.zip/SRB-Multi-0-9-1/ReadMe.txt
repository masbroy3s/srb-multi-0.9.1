SRBMiner-MULTI CPU & AMD GPU Miner
==================================================================
https://www.srbminer.com

SRBMiner-Multi is a cryptocurrency miner that can mine up to 4 different algorithms/coins at the same time!
It can mine with both your CPU and GPU (AMD only) devices.
Supported OS: Win64 & Linux

For a list of supported algorithms and their devfee's, run miner with --list-algorithms parameter.
For a list of parameters to set up the miner, run miner with --help parameter.


==================================================================
SUPPORTED GPU'S
==================================================================


+ RX 6500/6700/6800/6900 
+ RX 5300/5400/5500/5600/5700
+ VEGA 56/64/FE/VII
+ RX 460/470/480/550/560/570/580/590
+ R9 280/280X/285/285X/380/380X
+ R9 290/290X
+ R9 Fury/Nano


==================================================================
SUPPORT
==================================================================


Forum:
https://bitcointalk.org/index.php?topic=5190081.0

Discord:
https://discord.gg/zXY23De

Youtube:
https://www.youtube.com/c/SRBMinerCPUGPUminer


==================================================================
INFORMATIONS, NOTES AND LICENSES
==================================================================


SRBMiner-MULTI uses a part of WinIO library from Yariv Kaplan.
SRBMiner-MULTI uses a part of WinRing0 library from OpenLibSys.org.
SRBMiner-MULTI uses the RandomX library from Tevador (tevador@gmail.com).


LICENSES:

WinIO
==============
END USER LICENSE AGREEMENT

Software License Agreement for WinIo
The following terms apply to all files associated with the software unless
explicitly disclaimed in individual files.

IMPORTANT- PLEASE READ CAREFULLY: BY INSTALLING THE SOFTWARE (AS DEFINED BELOW),
OR COPYING THE SOFTWARE, YOU (EITHER ON BEHALF OF YOURSELF AS AN INDIVIDUAL OR
ON BEHALF OF AN ENTITY AS ITS AUTHORIZED REPRESENTATIVE) AGREE TO ALL OF THE
TERMS OF THIS END USER LICENSE AGREEMENT ("AGREEMENT") REGARDING YOUR USE OF
THE SOFTWARE. IF YOU DO NOT AGREE WITH ALL OF THE TERMS OF THIS AGREEMENT, DO
NOT INSTALL, COPY OR OTHERWISE USE THE SOFTWARE.

1. GRANT OF LICENSE: Subject to the terms below, Yariv Kaplan ("AUTHOR") hereby
grants you a non-exclusive, non-transferable, non-assignable license to install
and to use the downloadable version of WinIo ("SOFTWARE").

a. Redistributable Code. You may reproduce and distribute the object code form
of the SOFTWARE solely in conjunction with, and as part of, your application
("Permitted Application"); provided that you comply with the following:

If you redistribute any portion of the Redistributable Code, you agree that:

(i) you will only distribute the Redistributable Code in conjunction with, and
as part of, your Permitted Application which adds significant functionality to
the Redistributable Code and that distribution of the Permitted Application does
not compete with the AUTHOR's distribution of the SOFTWARE;

(ii) you will include a valid copyright notice on your Permitted Application;

(iii) you will not permit further redistribution of the Redistributable Code;

(iv) you will indemnify, hold harmless, and defend the AUTHOR from and against
any claims or lawsuits, including attorneys' fees, that arise or result from
the use or distribution of your Permitted Application.

b. License to use Source Code. You may not sell, lease, rent, transfer or
sublicense the source code of this SOFTWARE.

2. MODIFICATION: SOFTWARE Source Code may be modified without the prior written
permission of the AUTHOR. Any modifications made to the SOFTWARE will continue
to be subject to the terms and conditions of this AGREEMENT.

3. COPYRIGHT: All rights, title, and copyrights in and to the SOFTWARE and any
copies of the SOFTWARE are owned by the AUTHOR. The SOFTWARE is protected by
copyright laws and international treaty provisions. Therefore, you must treat
the SOFTWARE like any other copyrighted material.

4. TITLE: You acknowledge that no title to the intellectual property in the
SOFTWARE is transferred to you. Title, ownership, rights, and intellectual
property rights in and to the SOFTWARE shall remain the exclusive property of
the AUTHOR. The SOFTWARE is protected by copyright laws of the United States
and international treaties.

5. LIMITATION OF LIABILITY: You must assume the entire risk of using the
SOFTWARE.

IN NO EVENT SHALL THE AUTHOR BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT,
SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OF THIS
SOFTWARE, ITS DOCUMENTATION, OR ANY DERIVATIVES THEREOF, EVEN IF THE AUTHOR
HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

THE AUTHOR SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT LIMITED
TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE, AND NON-INFRINGEMENT. THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS,
AND THE AUTHOR HAS NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
ENHANCEMENTS, OR MODIFICATIONS.




WinRing0
==============
Copyright (c) 2007-2009 OpenLibSys.org. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.




RandomX
==============
Copyright (c) 2018-2019, tevador <tevador@gmail.com>
Copyright (c) 2014-2019, The Monero Project

All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
	* Redistributions of source code must retain the above copyright
	  notice, this list of conditions and the following disclaimer.
	* Redistributions in binary form must reproduce the above copyright
	  notice, this list of conditions and the following disclaimer in the
	  documentation and/or other materials provided with the distribution.
	* Neither the name of the copyright holder nor the
	  names of its contributors may be used to endorse or promote products
	  derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
